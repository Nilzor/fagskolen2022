package paradigmer

fun main() {
    // En list av "Any" (dvs hvilken som helst type)
    // første element [0] representerer lysstyrke
    // andre element [1] representerer av/på
    val dimmerState1 = listOf(0.0, false)
    println("Dimmer lightness now: ${dimmerState1[0]}")
    val dimmerState2 = increaseDimmerLightness(dimmerState1)
    println("Dimmer lightness now: ${dimmerState2[0]}")
    val dimmerState3 = increaseDimmerLightness(dimmerState2)
    println("Dimmer lightness now: ${dimmerState3[0]}")

    // Merk hvordan vi bare bruker "val" her i motsetning til DimmerProcedural
}

fun increaseDimmerLightness(state: List<Any>): List<Any> {
    var newLightValue = state[0] as Double + 0.1
    if (newLightValue > 1) {
        newLightValue = 1.0
    }
    return listOf(newLightValue, state[1])
}