fun main() {
    var dimmerLightness = 0.0
    var dimmerIsOn = false

    println("Dimmer lightness now: $dimmerLightness")
    dimmerLightness = increaseDimmerLightness(dimmerLightness)
    println("Dimmer lightness now: $dimmerLightness")
    dimmerLightness = increaseDimmerLightness(dimmerLightness)
    println("Dimmer lightness now: $dimmerLightness")
}

fun increaseDimmerLightness(lightValue: Double): Double {
    var newLightValue = lightValue + 0.1
    if (newLightValue > 1) {
        newLightValue = 1.0
    }
    return newLightValue
}

fun toggleDimmer(isOn: Boolean): Boolean {
    return !isOn
}